// Base code for program 3 - does not compile as is, needs other files 
//and shaders but has skeleton for much of the data transfer for shading
//and traversal of the mesh for computing normals - you must compute normals

#include <stdio.h>
#include <stdlib.h>
//#include <GL/glew.h>
//#include <GLFW/glfw3.h>
#include "glew.h"
#include "glfw3.h"
#include <iostream>
#include <cassert>
#include <cmath>
#include <stdio.h>
#include "GLSL.h"
#include "tiny_obj_loader.h"
#include "glm/glm.hpp"
#include "glm/gtc/matrix_transform.hpp" //perspective, trans etc
#include "glm/gtc/type_ptr.hpp" //value_ptr

GLFWwindow* window;
using namespace std;

vector<tinyobj::shape_t> shapes;
vector<tinyobj::material_t> materials;

int g_SM = 0;
int g_N = 0;
int g_width;
int g_height;
float g_Camtrans = -2.5;
float g_Yangle = 0;
float g_Xangle = 0;
int g_mat_id =0;
glm::vec3 g_trans(0, 0, 0);
glm::vec3 g_light(2, 6, 6);

GLuint ShadeProg;
GLuint posBufObj = 0;
GLuint norBufObj = 0;
GLuint indBufObj = 0;

//Handles to the shader data
GLint h_aPosition;
GLint h_aNormal;
GLint h_uModelMatrix;
GLint h_uRotate;
GLint h_uViewMatrix;
GLint h_uProjMatrix;
GLint h_uLightPos;
GLint h_uMatAmb, h_uMatDif, h_uMatSpec, h_uMatShine;
GLint h_uShadeM;
GLint h_uLSrc;
GLint h_uColorNormal;

/* helper function to make sure your matrix handle is correct */
inline void safe_glUniformMatrix4fv(const GLint handle, const GLfloat data[]) {
  if (handle >= 0)
    glUniformMatrix4fv(handle, 1, GL_FALSE, data);
}

/* helper function to send materials to the shader - you must create your own */
void SetMaterial(int i) {
 
  glUseProgram(ShadeProg);
  switch (i) {
    case -1: //light source
        glUniform3f(h_uMatAmb, 1.0, 1.0, 1.0);
        glUniform3f(h_uMatDif, 1.0, 1.0, 1.0);
        glUniform3f(h_uMatSpec, 1.0, 1.0, 1.0);
        glUniform1f(h_uMatShine, 1000.0);
        break;
    case 0: //shiny blue plastic
        glUniform3f(h_uMatAmb, 0.02, 0.02, 0.1);
        glUniform3f(h_uMatDif, 0.0, 0.08, 0.5);
        glUniform3f(h_uMatSpec, 0.14, 0.14, 0.4);
        glUniform1f(h_uMatShine, 120.0);
        break;
    case 1: // flat grey
        glUniform3f(h_uMatAmb, 0.13, 0.13, 0.14);
        glUniform3f(h_uMatDif, 0.3, 0.3, 0.4);
        glUniform3f(h_uMatSpec, 0.3, 0.3, 0.4);
        glUniform1f(h_uMatShine, 4.0);
        break;
    case 2: //gold
        glUniform3f(h_uMatAmb, 0.09, 0.07, 0.08);
        glUniform3f(h_uMatDif, 0.91, 0.782, 0.82);
        glUniform3f(h_uMatSpec, 1.0, 0.913, 0.8);
        glUniform1f(h_uMatShine, 200.0);
        break;
    case 3: //shiny black
        glUniform3f(h_uMatAmb, 0.0, 0.0, 0.0);
        glUniform3f(h_uMatDif, 0.0, 0.0, 0.0);
        glUniform3f(h_uMatSpec, 1.0, 1.0, 1.0);
        glUniform1f(h_uMatShine, 150.0);
        break;
    case 4: //ruby jewel
        glm::vec3 col = glm::vec3(0.607, 0.066, 0.117);
        glUniform3f(h_uMatAmb, col.x/10.0, col.y/10.0, col.z/10.0);
        glUniform3f(h_uMatDif, col.x/3.0, col.y/3.0, col.z/3.0);
        glUniform3f(h_uMatSpec, col.x/1.0, col.y/1.0, col.z/1.0);
        glUniform1f(h_uMatShine, 300.0);
        break;
  }
}

/* helper function to set projection matrix - don't touch */
void SetProjectionMatrix() {
  glm::mat4 Projection = glm::perspective(90.0f, (float)g_width/g_height, 0.1f, 100.f);
  safe_glUniformMatrix4fv(h_uProjMatrix, glm::value_ptr(Projection));
}

/* camera controls - do not change beyond the current set up to rotate*/
void SetView() {
  glm::mat4 Trans = glm::translate( glm::mat4(1.0f), glm::vec3(0.0f, 0, g_Camtrans));
  safe_glUniformMatrix4fv(h_uViewMatrix, glm::value_ptr(Trans));
}

/* model transforms */
void SetModel(int id) {
   glm::vec3 trans;
   glm::vec3 scale;
   float Yangle;
   float Xangle;

   if (id == 0) {
      scale = glm::vec3(1.0, 1.0, 1.0);
      trans = g_trans;
      Yangle = g_Yangle;
      Xangle = g_Xangle;
   } else if (id == 1) {
      scale = glm::vec3(0.5, 0.5, 0.5);
      trans = g_trans + glm::vec3(4.0, -1.0, 0.0);
      Yangle = g_Yangle;
      Xangle = g_Xangle;
   } else if (id == 2) {
      scale = glm::vec3(0.25, 0.25, 0.25);
      trans = g_trans + glm::vec3(-8.0, -4.0, 0.0);
      Yangle = g_Yangle;
      Xangle = g_Xangle;
   } else if (id == -1) { // light source
      scale = glm::vec3(1.0, 1.0, 1.0);
      trans = g_light;
      Yangle = 0;
      Xangle = 0;
   }

  glm::mat4 Scale = glm::scale( glm::mat4(1.0f), scale);
  glm::mat4 Trans = glm::translate( glm::mat4(1.0f), trans);
  glm::mat4 RotateY = glm::rotate( glm::mat4(1.0f), Yangle, glm::vec3(0, 1, 0));
  glm::mat4 RotateX = glm::rotate( glm::mat4(1.0f), Xangle, glm::vec3(1, 0, 0));
  glm::mat4 com = Scale*RotateY*RotateX*Trans;
  safe_glUniformMatrix4fv(h_uModelMatrix, glm::value_ptr(com));

   // Send rotation matrix for normals
  glm::mat4 rot = RotateY*RotateX;
  safe_glUniformMatrix4fv(h_uRotate, glm::value_ptr(rot));
}

//Given a vector of shapes which has already been read from an obj file
// resize all vertices to the range [-1, 1]
void resize_obj(std::vector<tinyobj::shape_t> &shapes){
    float minX, minY, minZ;
    float maxX, maxY, maxZ;
    float scaleX, scaleY, scaleZ;
    float shiftX, shiftY, shiftZ;
    float epsilon = 0.001;

    minX = minY = minZ = 1.1754E+38F;
    maxX = maxY = maxZ = -1.1754E+38F;

    //Go through all vertices to determine min and max of each dimension
    for (size_t i = 0; i < shapes.size(); i++) {
        for (size_t v = 0; v < shapes[i].mesh.positions.size() / 3; v++) {
            if(shapes[i].mesh.positions[3*v+0] < minX) minX = shapes[i].mesh.positions[3*v+0];
            if(shapes[i].mesh.positions[3*v+0] > maxX) maxX = shapes[i].mesh.positions[3*v+0];

            if(shapes[i].mesh.positions[3*v+1] < minY) minY = shapes[i].mesh.positions[3*v+1];
            if(shapes[i].mesh.positions[3*v+1] > maxY) maxY = shapes[i].mesh.positions[3*v+1];

            if(shapes[i].mesh.positions[3*v+2] < minZ) minZ = shapes[i].mesh.positions[3*v+2];
            if(shapes[i].mesh.positions[3*v+2] > maxZ) maxZ = shapes[i].mesh.positions[3*v+2];
        }
    }
   //From min and max compute necessary scale and shift for each dimension
   float maxExtent, xExtent, yExtent, zExtent;
   xExtent = maxX-minX;
   yExtent = maxY-minY;
   zExtent = maxZ-minZ;
   if (xExtent >= yExtent && xExtent >= zExtent) {
     maxExtent = xExtent;
   }
   if (yExtent >= xExtent && yExtent >= zExtent) {
     maxExtent = yExtent;
   }
   if (zExtent >= xExtent && zExtent >= yExtent) {
     maxExtent = zExtent;
   }
    scaleX = 2.0 /maxExtent;
    shiftX = minX + (xExtent/ 2.0);
    scaleY = 2.0 / maxExtent;
    shiftY = minY + (yExtent / 2.0);
    scaleZ = 2.0/ maxExtent;
    shiftZ = minZ + (zExtent)/2.0;

    //Go through all verticies shift and scale them
    for (size_t i = 0; i < shapes.size(); i++) {
        for (size_t v = 0; v < shapes[i].mesh.positions.size() / 3; v++) {
            shapes[i].mesh.positions[3*v+0] = (shapes[i].mesh.positions[3*v+0] - shiftX) * scaleX;
            assert(shapes[i].mesh.positions[3*v+0] >= -1.0 - epsilon);
            assert(shapes[i].mesh.positions[3*v+0] <= 1.0 + epsilon);
            shapes[i].mesh.positions[3*v+1] = (shapes[i].mesh.positions[3*v+1] - shiftY) * scaleY;
            assert(shapes[i].mesh.positions[3*v+1] >= -1.0 - epsilon);
            assert(shapes[i].mesh.positions[3*v+1] <= 1.0 + epsilon);
            shapes[i].mesh.positions[3*v+2] = (shapes[i].mesh.positions[3*v+2] - shiftZ) * scaleZ;
            assert(shapes[i].mesh.positions[3*v+2] >= -1.0 - epsilon);
            assert(shapes[i].mesh.positions[3*v+2] <= 1.0 + epsilon);
        }
    }
}



void loadShapes(const string &objFile)
{
	string err = tinyobj::LoadObj(shapes, materials, objFile.c_str());
	if(!err.empty()) {
		cerr << err << endl;
	}
   resize_obj(shapes);
}

void initGL()
{
	// Set the background color
	glClearColor(0.6f, 0.6f, 0.8f, 1.0f);
	// Enable Z-buffer test
	glEnable(GL_DEPTH_TEST);
   glPointSize(18);
	
	// Send the position array to the GPU
	const vector<float> &posBuf = shapes[0].mesh.positions;
	glGenBuffers(1, &posBufObj);
	glBindBuffer(GL_ARRAY_BUFFER, posBufObj);
	glBufferData(GL_ARRAY_BUFFER, posBuf.size()*sizeof(float), &posBuf[0], GL_STATIC_DRAW);
	
	// TODO compute the normals per vertex - you must fill this in 
	vector<float> norBuf;
	vector<glm::vec3> crossBuf;
   int idx1, idx2, idx3;
   glm::vec3 v1, v2, v3;
   glm::vec3 vec1, vec2, vec3;
   glm::vec3 cross1, cross2, cross3;
   //for every vertex initialize a normal to 0
   for (int j = 0; j < shapes[0].mesh.positions.size()/3; j++) {
      norBuf.push_back(0);
      norBuf.push_back(0);
      norBuf.push_back(0);

      crossBuf.push_back(glm::vec3(0, 0, 0));
   }
   // DO work here to compute the normals for every face
   //then add its normal to its associated vertex
   for (int i = 0; i < shapes[0].mesh.indices.size()/3; i++) {
      idx1 = shapes[0].mesh.indices[3*i+0];
      idx2 = shapes[0].mesh.indices[3*i+1];
      idx3 = shapes[0].mesh.indices[3*i+2];
      v1 = glm::vec3(shapes[0].mesh.positions[3*idx1 +0],shapes[0].mesh.positions[3*idx1 +1], shapes[0].mesh.positions[3*idx1 +2]); 
      v2 = glm::vec3(shapes[0].mesh.positions[3*idx2 +0],shapes[0].mesh.positions[3*idx2 +1], shapes[0].mesh.positions[3*idx2 +2]); 
      v3 = glm::vec3(shapes[0].mesh.positions[3*idx3 +0],shapes[0].mesh.positions[3*idx3 +1], shapes[0].mesh.positions[3*idx3 +2]); 

      vec1 = glm::normalize(v1 - v2);
      vec2 = glm::normalize(v2 - v3);
      vec3 = glm::normalize(v3 - v1);

      cross1 = glm::cross(vec1, vec2);
      cross2 = glm::cross(vec2, vec3);
      cross3 = glm::cross(vec3, vec1);

      crossBuf[idx1] += cross1;
      crossBuf[idx2] += cross2;
      crossBuf[idx3] += cross3;
   }

   // Cross products have been added together, normalize then set normals buffer
   for (int i = 0; i < shapes[0].mesh.indices.size()/3; i++) {
      idx1 = shapes[0].mesh.indices[3*i+0];
      idx2 = shapes[0].mesh.indices[3*i+1];
      idx3 = shapes[0].mesh.indices[3*i+2];

      cross1 = glm::normalize(crossBuf[idx1]);
      cross2 = glm::normalize(crossBuf[idx2]);
      cross3 = glm::normalize(crossBuf[idx3]);

      norBuf[3*idx1+0] = cross1.x;
      norBuf[3*idx1+1] = cross1.y;
      norBuf[3*idx1+2] = cross1.z;
      norBuf[3*idx2+0] = cross2.x;
      norBuf[3*idx2+1] = cross2.y;
      norBuf[3*idx2+2] = cross2.z;
      norBuf[3*idx3+0] = cross3.x;
      norBuf[3*idx3+1] = cross3.y;
      norBuf[3*idx3+2] = cross3.z;
   }

	glGenBuffers(1, &norBufObj);
	glBindBuffer(GL_ARRAY_BUFFER, norBufObj);
	glBufferData(GL_ARRAY_BUFFER, norBuf.size()*sizeof(float), &norBuf[0], GL_STATIC_DRAW);
	
	// Send the index array to the GPU
	const vector<unsigned int> &indBuf = shapes[0].mesh.indices;
	glGenBuffers(1, &indBufObj);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, indBufObj);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, indBuf.size()*sizeof(unsigned int), &indBuf[0], GL_STATIC_DRAW);

	// Unbind the arrays
	glBindBuffer(GL_ARRAY_BUFFER, 0);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
	GLSL::checkVersion();
	assert(glGetError() == GL_NO_ERROR);

}

bool installShaders(const string &vShaderName, const string &fShaderName)
{
	GLint rc;
	
	// Create shader handles
	GLuint VS = glCreateShader(GL_VERTEX_SHADER);
	GLuint FS = glCreateShader(GL_FRAGMENT_SHADER);
	
	// Read shader sources
	const char *vshader = GLSL::textFileRead(vShaderName.c_str());
	const char *fshader = GLSL::textFileRead(fShaderName.c_str());
	glShaderSource(VS, 1, &vshader, NULL);
	glShaderSource(FS, 1, &fshader, NULL);
	
	// Compile vertex shader
	glCompileShader(VS);
	GLSL::printError();
	glGetShaderiv(VS, GL_COMPILE_STATUS, &rc);
	GLSL::printShaderInfoLog(VS);
	if(!rc) {
		printf("Error compiling vertex shader %s\n", vShaderName.c_str());
		return false;
	}
	
	// Compile fragment shader
	glCompileShader(FS);
	GLSL::printError();
	glGetShaderiv(FS, GL_COMPILE_STATUS, &rc);
	GLSL::printShaderInfoLog(FS);
	if(!rc) {
		printf("Error compiling fragment shader %s\n", fShaderName.c_str());
		return false;
	}
	
	// Create the program and link
	   ShadeProg = glCreateProgram();
	   glAttachShader(ShadeProg, VS);
	   glAttachShader(ShadeProg, FS);
	   glLinkProgram(ShadeProg);
   
	   GLSL::printError();
	   glGetProgramiv(ShadeProg, GL_LINK_STATUS, &rc);
	   GLSL::printProgramInfoLog(ShadeProg);
	   if(!rc) {
		   printf("Error linking shaders %s and %s\n", vShaderName.c_str(), fShaderName.c_str());
		   return false;
	   }

   /* get handles to attribute data */
    h_aPosition = GLSL::getAttribLocation(ShadeProg, "aPos");
    h_aNormal = GLSL::getAttribLocation(ShadeProg, "aNor");
    h_uProjMatrix = GLSL::getUniformLocation(ShadeProg, "uP");
    h_uViewMatrix = GLSL::getUniformLocation(ShadeProg, "uV");
    h_uModelMatrix = GLSL::getUniformLocation(ShadeProg, "uM");
    h_uRotate = GLSL::getUniformLocation(ShadeProg, "uR");
    h_uLightPos = GLSL::getUniformLocation(ShadeProg, "uL");
    h_uMatAmb = GLSL::getUniformLocation(ShadeProg, "uaClr");
    h_uMatDif = GLSL::getUniformLocation(ShadeProg, "udClr");
    h_uMatSpec = GLSL::getUniformLocation(ShadeProg, "usClr");
    h_uMatShine = GLSL::getUniformLocation(ShadeProg, "uShine");
    h_uShadeM = GLSL::getUniformLocation(ShadeProg, "uShadeM");
    h_uLSrc = GLSL::getUniformLocation(ShadeProg, "uLSrc");
    h_uColorNormal = GLSL::getUniformLocation(ShadeProg, "uClrNor");
	
	assert(glGetError() == GL_NO_ERROR);
	return true;
}


void drawGL()
{
	// Clear the screen
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	
	// Use our GLSL program
	glUseProgram(ShadeProg);

   SetProjectionMatrix();
   SetView();

   glUniform1i(h_uLSrc, 0);

   SetModel(0);
   SetMaterial(g_mat_id);
   glUniform3f(h_uLightPos, g_light.x, g_light.y, g_light.z);
   glUniform1i(h_uShadeM, g_SM);
   glUniform1i(h_uColorNormal, g_N);

	// Enable and bind position array for drawing
	GLSL::enableVertexAttribArray(h_aPosition);
	glBindBuffer(GL_ARRAY_BUFFER, posBufObj);
	glVertexAttribPointer(h_aPosition, 3, GL_FLOAT, GL_FALSE, 0, 0);
	
	// Enable and bind normal array for drawing
	GLSL::enableVertexAttribArray(h_aNormal);
	glBindBuffer(GL_ARRAY_BUFFER, norBufObj);
	glVertexAttribPointer(h_aNormal, 3, GL_FLOAT, GL_FALSE, 0, 0);
	
	// Bind index array for drawing
	int nIndices = (int)shapes[0].mesh.indices.size();
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, indBufObj);
	
	glDrawElements(GL_TRIANGLES, nIndices, GL_UNSIGNED_INT, 0);

   // Draw second bunny (right)
   SetModel(1);
   SetMaterial((g_mat_id+1)%5);
	glDrawElements(GL_TRIANGLES, nIndices, GL_UNSIGNED_INT, 0);

   // Draw third bunny (left)
   SetModel(2);
   SetMaterial((g_mat_id+4)%5);
	glDrawElements(GL_TRIANGLES, nIndices, GL_UNSIGNED_INT, 0);
	
   // Draw light source bunny last
   glUniform1i(h_uLSrc, 1);
   SetModel(-1);
   SetMaterial(-1);
	glDrawElements(GL_TRIANGLES, nIndices, GL_UNSIGNED_INT, 0);
	
   GLSL::disableVertexAttribArray(h_aPosition);
	GLSL::disableVertexAttribArray(h_aNormal);
	glBindBuffer(GL_ARRAY_BUFFER, 0);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
	
   // Disable and unbind
	glBindBuffer(GL_ARRAY_BUFFER, 0);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
	glUseProgram(0);
	assert(glGetError() == GL_NO_ERROR);
	
}


void window_size_callback(GLFWwindow* window, int w, int h){
	glViewport(0, 0, (GLsizei)w, (GLsizei)h);
	g_width = w;
	g_height = h;
}

void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_A && action == GLFW_PRESS || action == GLFW_REPEAT)
      g_Yangle += 10;
    if (key == GLFW_KEY_D && action == GLFW_PRESS || action == GLFW_REPEAT)
       g_Yangle -= 10;
    if (key == GLFW_KEY_W && action == GLFW_PRESS || action == GLFW_REPEAT)
      g_Xangle += 10;
    if (key == GLFW_KEY_S && action == GLFW_PRESS || action == GLFW_REPEAT)
      g_Xangle -= 10;
    if (key == GLFW_KEY_X && action == GLFW_PRESS)
     g_mat_id = (g_mat_id+1)%5; 
    if (key == GLFW_KEY_Z && action == GLFW_PRESS)
     g_SM = !g_SM; 
    if (key == GLFW_KEY_Q && (action == GLFW_PRESS || action == GLFW_REPEAT))
     g_light.x -= 0.25; 
    if (key == GLFW_KEY_E && (action == GLFW_PRESS || action == GLFW_REPEAT))
     g_light.x += 0.25; 
    if (key == GLFW_KEY_R && (action == GLFW_PRESS || action == GLFW_REPEAT))
     g_light.z -= 0.25; 
    if (key == GLFW_KEY_F && (action == GLFW_PRESS || action == GLFW_REPEAT))
     g_light.z += 0.25; 
    if (key == GLFW_KEY_N && action == GLFW_PRESS)
     g_N = !g_N; 
}

int main(int argc, char **argv)
{

   // Initialise GLFW
   if( !glfwInit() )
   {
       fprintf( stderr, "Failed to initialize GLFW\n" );
       return -1;
   }

   glfwWindowHint(GLFW_SAMPLES, 4);
   glfwWindowHint(GLFW_RESIZABLE,GL_FALSE);
   glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 2);
   glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 1);

    // Open a window and create its OpenGL context
   g_width = 1024;
   g_height = 768;
   window = glfwCreateWindow( g_width, g_height, "P3 - shading", NULL, NULL);
   if( window == NULL ){
      fprintf( stderr, "Failed to open GLFW window. If you have an Intel GPU, they are not 3.3 compatible. Try the 2.1 version of the tutorials.\n" );
        glfwTerminate();
        return -1;
    }
    glfwMakeContextCurrent(window);
    glfwSetKeyCallback(window, key_callback);
    glfwSetWindowSizeCallback(window, window_size_callback);
   // Initialize GLEW
   if (glewInit() != GLEW_OK) {
      fprintf(stderr, "Failed to initialize GLEW\n");
      return -1;
   }

   // Ensure we can capture the escape key being pressed below
   glfwSetInputMode(window, GLFW_STICKY_KEYS, GL_TRUE);

   glEnable (GL_BLEND);
   glBlendFunc (GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	loadShapes("bunny.obj");
	initGL();
	installShaders("vert.glsl", "frag.glsl");

	glClearColor(0.6f, 0.6f, 0.8f, 1.0f);


    do{
      drawGL();
      // Swap buffers
      glfwSwapBuffers(window);
      glfwPollEvents();

    } // Check if the ESC key was pressed or the window was closed
   while( glfwGetKey(window, GLFW_KEY_ESCAPE ) != GLFW_PRESS &&
         glfwWindowShouldClose(window) == 0 );

    // Close OpenGL window and terminate GLFW
    glfwTerminate();

	return 0;
}
